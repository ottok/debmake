#include <stdio.h>
int
main()
{
	printf("Hello, Debian packager!\n");
	return 0;
}
