/* config.h.  Generated from config.h.in by configure.  */
/* config.h.in.  Generated from configure.ac by autoheader.  */

/* Name of package */
#define PACKAGE "hello-auto"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "foo@example.org"

/* Define to the full name of this package. */
#define PACKAGE_NAME "hello-auto"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "hello-auto 1.0"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "hello-auto"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "1.0"

/* Version number of package */
#define VERSION "1.0"
