#!/usr/bin/python3
# vim:se tw=0 sts=4 ts=4 et ai:

def main():
    print('Hello Python3!')
    return

if __name__ == '__main__':
    main()

